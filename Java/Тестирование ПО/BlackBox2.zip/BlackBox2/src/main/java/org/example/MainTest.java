package org.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.logging.Logger;

public class MainTest {
    private static final Logger logger = Logger.getLogger(MainTest.class.getName());

    @Test
    public void testIsDivisor_True() {
        logger.info("Тест: проверка на делимость (позитивные случаи)");
        assertTrue(Main.isDivisor(2, 4), "2 должно быть делителем 4");
        assertTrue(Main.isDivisor(5, 25), "5 должно быть делителем 25");
        assertTrue(Main.isDivisor(10, 100), "10 должно быть делителем 100");
    }

    @Test
    public void testIsDivisor_False() {
        logger.info("Тест: проверка на делимость (негативные случаи)");
        assertFalse(Main.isDivisor(3, 10), "3 не должно быть делителем 10");
        assertFalse(Main.isDivisor(6, 20), "6 не должно быть делителем 20");
        assertFalse(Main.isDivisor(7, 50), "7 не должно быть делителем 50");
    }
}



