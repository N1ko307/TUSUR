package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int x = getInput("Введите x (2..100): ", 2, 100);
        int y = getInput("Введите y (2..100): ", 2, 100);

        boolean result = isDivisor(x, y);
        System.out.println("Число " + x + " является делителем числа " + y + ": " + result);
    }

    static int getInput(String message, int min, int max) {
        Scanner scanner = new Scanner(System.in);
        int number;
        while (true) {
            System.out.print(message);
            if (scanner.hasNextInt()) {
                number = scanner.nextInt();
                if (number >= min && number <= max) {
                    return number;
                } else {
                    System.out.println("Ошибка: число должно быть в диапазоне от " + min + " до " + max);
                }
            } else {
                System.out.println("Ошибка: введите целое число");
                scanner.next(); // Очистить неправильный ввод
            }
        }
    }

    static boolean isDivisor(int x, int y) {
        return y % x == 0;
    }
}
